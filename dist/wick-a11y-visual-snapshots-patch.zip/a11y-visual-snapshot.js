/**
 * Lightweight DOM + computed-style snapshots for HTML reports (no Cypress screenshots).
 * Runs in the AUT window alongside the live a11y monitor.
 */

const SKIP_TAGS = new Set([
  'SCRIPT',
  'STYLE',
  'NOSCRIPT',
  'TEMPLATE',
  'LINK',
  'META',
  'TITLE',
  'HEAD',
  'SVG',
  'IFRAME',
  'OBJECT',
  'EMBED',
]);

/** Default whitelist of computed properties copied onto inline `style` for previews. */
export const DEFAULT_VISUAL_STYLE_PROPS = [
  'display',
  'position',
  'top',
  'left',
  'right',
  'bottom',
  'width',
  'height',
  'max-width',
  'max-height',
  'min-width',
  'min-height',
  'margin',
  'margin-top',
  'margin-right',
  'margin-bottom',
  'margin-left',
  'padding',
  'padding-top',
  'padding-right',
  'padding-bottom',
  'padding-left',
  'border',
  'border-top',
  'border-right',
  'border-bottom',
  'border-left',
  'border-radius',
  'border-collapse',
  'box-sizing',
  'background-color',
  'color',
  'font-family',
  'font-size',
  'font-weight',
  'font-style',
  'line-height',
  'letter-spacing',
  'text-align',
  'text-decoration',
  'text-transform',
  'vertical-align',
  'white-space',
  'opacity',
  'visibility',
  'overflow',
  'overflow-x',
  'overflow-y',
  'box-shadow',
  'flex',
  'flex-direction',
  'flex-wrap',
  'flex-grow',
  'flex-shrink',
  'flex-basis',
  'align-items',
  'align-self',
  'justify-content',
  'justify-items',
  'gap',
  'grid-template-columns',
  'grid-template-rows',
  'grid-column',
  'grid-row',
  'list-style',
  'list-style-type',
  'cursor',
  'z-index',
];

export const DEFAULT_VISUAL_SNAPSHOT_OPTIONS = {
  enabled: true,
  maxNodesPerScan: 48,
  pageOverview: {
    enabled: true,
    maxDepth: 5,
    maxNodes: 450,
    maxTextChars: 72,
    rootSelector: 'body',
  },
  element: {
    enabled: true,
    maxDepth: 8,
    maxNodes: 140,
    maxTextChars: 120,
  },
  styleProps: DEFAULT_VISUAL_STYLE_PROPS,
};

/**
 * @param {Record<string, unknown> | null | undefined} user
 * @returns {typeof DEFAULT_VISUAL_SNAPSHOT_OPTIONS & { styleProps: string[] }}
 */
export function normalizeVisualSnapshotOptions(user) {
  const u = user && typeof user === 'object' ? user : {};
  const page = {
    ...DEFAULT_VISUAL_SNAPSHOT_OPTIONS.pageOverview,
    ...(u.pageOverview && typeof u.pageOverview === 'object' ? u.pageOverview : {}),
  };
  const element = {
    ...DEFAULT_VISUAL_SNAPSHOT_OPTIONS.element,
    ...(u.element && typeof u.element === 'object' ? u.element : {}),
  };
  const styleProps = Array.isArray(u.styleProps) && u.styleProps.length > 0
    ? u.styleProps.map((s) => String(s))
    : [...DEFAULT_VISUAL_STYLE_PROPS];

  return {
    ...DEFAULT_VISUAL_SNAPSHOT_OPTIONS,
    ...u,
    pageOverview: page,
    element,
    styleProps,
  };
}

/**
 * Resolve axe node.target (selector chain) to an element; supports iframe hops for same-origin frames.
 * @param {Window} win
 * @param {Document} doc
 * @param {string[]} target
 * @returns {Element | null}
 */
export function resolveTargetToElement(win, doc, target) {
  if (!target || !Array.isArray(target) || target.length === 0) return null;

  let current = null;

  for (let i = 0; i < target.length; i++) {
    const sel = String(target[i] || '').trim();
    if (!sel) return null;

    let next = null;
    try {
      if (i === 0) {
        next = doc.querySelector(sel);
      } else if (current && current.tagName === 'IFRAME') {
        const frameDoc = current.contentDocument;
        if (!frameDoc) return null;
        next = frameDoc.querySelector(sel);
      } else if (current) {
        next = current.querySelector(sel);
      } else {
        next = doc.querySelector(sel);
      }
    } catch {
      return null;
    }

    if (!next) return null;
    current = next;
  }

  return current && current.nodeType === 1 ? current : null;
}

function truncateAttr(name, value, maxLen) {
  const n = String(name || '').toLowerCase();
  const s = String(value ?? '');
  if (n === 'href' || n === 'src' || n.startsWith('data-')) {
    return s.length > maxLen ? `${s.slice(0, maxLen)}…` : s;
  }
  return s.length > maxLen ? `${s.slice(0, maxLen)}…` : s;
}

/**
 * @param {Element} el
 * @returns {Record<string, string>}
 */
function pickAllowedAttributes(el) {
  const out = {};
  const allowed = new Set([
    'id',
    'class',
    'href',
    'src',
    'alt',
    'title',
    'role',
    'type',
    'name',
    'value',
    'placeholder',
    'for',
    'colspan',
    'rowspan',
    'scope',
    'disabled',
    'readonly',
    'checked',
    'selected',
  ]);
  const maxLen = 96;

  for (const attr of el.attributes || []) {
    const name = attr.name;
    if (allowed.has(name) || name.startsWith('data-')) {
      out[name] = truncateAttr(name, attr.value, maxLen);
    }
  }
  return out;
}

/**
 * @param {CSSStyleDeclaration} cs
 * @param {string[]} props
 */
function styleObjectFromComputed(cs, props) {
  const parts = [];
  for (const p of props) {
    try {
      const v = cs.getPropertyValue(p);
      if (v && String(v).trim()) {
        parts.push(`${p}:${v.trim()}`);
      }
    } catch {
      // ignore
    }
  }
  return parts.join(';');
}

/**
 * @param {Window} win
 * @param {Node} node
 * @param {object} opts
 * @param {number} depth
 * @param {{ n: number }} counter
 * @returns {object | null}
 */
function serializeNode(win, node, opts, depth, counter) {
  if (!node) return null;
  if (counter.n >= opts.maxNodes) {
    return { truncated: true };
  }

  if (node.nodeType === 3) {
    const raw = String(node.textContent || '').replace(/\s+/g, ' ').trim();
    if (!raw) return null;
    counter.n += 1;
    const t = raw.length > opts.maxTextChars ? `${raw.slice(0, opts.maxTextChars)}…` : raw;
    return { x: t };
  }

  if (node.nodeType !== 1) return null;

  const el = /** @type {Element} */ (node);
  const tag = el.tagName.toUpperCase();
  if (SKIP_TAGS.has(tag)) {
    return null;
  }

  if (tag === 'IFRAME') {
    counter.n += 1;
    return {
      t: 'div',
      s: 'border:1px dashed #79c0ff;padding:4px 6px;font-size:11px;color:#8fd1ff;background:rgba(48,74,110,.35)',
      c: [{ x: '[ iframe — preview unavailable in snapshot ]' }],
    };
  }

  if (depth > opts.maxDepth) {
    counter.n += 1;
    return {
      t: 'span',
      s: 'opacity:.65;font-size:10px',
      c: [{ x: `[ … deep subtree omitted (${tag}) ]` }],
    };
  }

  counter.n += 1;

  let styleStr = '';
  try {
    if (el.isConnected && win.getComputedStyle) {
      const cs = win.getComputedStyle(el);
      styleStr = styleObjectFromComputed(cs, opts.styleProps);
    }
  } catch {
    styleStr = '';
  }

  const attrs = pickAllowedAttributes(el);
  const childrenOut = [];

  const childNodes = el.childNodes;
  for (let i = 0; i < childNodes.length; i++) {
    if (counter.n >= opts.maxNodes) break;
    const serialized = serializeNode(win, childNodes[i], opts, depth + 1, counter);
    if (serialized) {
      if (serialized.truncated) {
        childrenOut.push({
          t: 'span',
          s: 'font-size:10px;opacity:.7',
          c: [{ x: '[ … ]' }],
        });
        break;
      }
      if (serialized.x != null) {
        childrenOut.push(serialized);
      } else if (serialized.t) {
        childrenOut.push(serialized);
      }
    }
  }

  return {
    t: el.tagName.toLowerCase(),
    ...(styleStr ? { s: styleStr } : {}),
    ...(Object.keys(attrs).length ? { a: attrs } : {}),
    ...(childrenOut.length ? { c: childrenOut } : {}),
  };
}

/**
 * @param {Window} win
 * @param {Element} root
 * @param {object} branchOpts
 */
export function captureElementSubtreeSnapshot(win, root, branchOpts) {
  const opts = {
    maxDepth: Number(branchOpts.maxDepth) || 8,
    maxNodes: Number(branchOpts.maxNodes) || 120,
    maxTextChars: Number(branchOpts.maxTextChars) || 100,
    styleProps: Array.isArray(branchOpts.styleProps) ? branchOpts.styleProps : DEFAULT_VISUAL_STYLE_PROPS,
  };

  if (!root || root.nodeType !== 1) {
    return { v: 1, err: 'no-element' };
  }

  try {
    if (!root.isConnected) {
      return { v: 1, err: 'detached' };
    }
  } catch {
    return { v: 1, err: 'detached' };
  }

  const counter = { n: 0 };
  let rect = null;
  try {
    const r = root.getBoundingClientRect();
    rect = {
      x: Math.round(r.x),
      y: Math.round(r.y),
      w: Math.round(r.width),
      h: Math.round(r.height),
    };
  } catch {
    rect = null;
  }

  let visibleHint = true;
  try {
    const cs = win.getComputedStyle(root);
    visibleHint =
      cs.visibility !== 'hidden' &&
      cs.display !== 'none' &&
      Number(cs.opacity) !== 0;
  } catch {
    visibleHint = false;
  }

  const node = serializeNode(win, root, opts, 0, counter);
  const truncated = counter.n >= opts.maxNodes || Boolean(node?.truncated);

  let r = null;
  if (!node) {
    r = null;
  } else if (node.truncated) {
    r = {
      t: 'div',
      s: 'padding:6px;border:1px dashed #888;font-size:11px;color:#666',
      c: [{ x: '[ subtree truncated for size ]' }],
    };
  } else {
    r = node;
  }

  return {
    v: 1,
    kind: 'element',
    rect,
    visibleHint,
    truncated,
    r,
  };
}

/**
 * Shallow structural view of the page (typically `body`).
 * @param {Window} win
 * @param {Document} doc
 * @param {object} pageOpts
 */
export function capturePageOverview(win, doc, pageOpts) {
  const opts = normalizeVisualSnapshotOptions({ pageOverview: pageOpts }).pageOverview;
  const sel = String(opts.rootSelector || 'body');
  let root = null;
  try {
    root = doc.querySelector(sel) || doc.body || doc.documentElement;
  } catch {
    root = doc.body || doc.documentElement;
  }

  if (!root) {
    return { v: 1, kind: 'page', err: 'no-root' };
  }

  const branch = {
    maxDepth: opts.maxDepth,
    maxNodes: opts.maxNodes,
    maxTextChars: opts.maxTextChars,
    styleProps: pageOpts.styleProps || DEFAULT_VISUAL_STYLE_PROPS,
  };

  const snap = captureElementSubtreeSnapshot(win, root, branch);
  let vw = 0;
  let vh = 0;
  try {
    vw = Math.round(win.innerWidth);
    vh = Math.round(win.innerHeight);
  } catch {
    // ignore
  }

  return {
    v: 1,
    kind: 'page',
    url: String(win.location?.href || ''),
    capturedAt: Date.now(),
    viewport: { w: vw, h: vh },
    rect: snap.rect,
    visibleHint: snap.visibleHint,
    truncated: snap.truncated,
    err: snap.err,
    r: snap.r,
  };
}

/**
 * Attach `visualSnapshot` to each axe node on violations/incomplete lists.
 * @param {Window} win
 * @param {Document} doc
 * @param {object} results axe-shaped { violations, incomplete }
 * @param {ReturnType<typeof normalizeVisualSnapshotOptions>} vsOpts
 */
export function enrichA11yResultsWithElementSnapshots(win, doc, results, vsOpts) {
  if (!vsOpts.enabled || !vsOpts.element?.enabled || !results) return;

  let budget = Math.max(0, Number(vsOpts.maxNodesPerScan) || 0);
  const lists = [results.violations, results.incomplete];

  for (const items of lists) {
    if (!Array.isArray(items) || budget <= 0) continue;

    for (const item of items) {
      const nodes = item?.nodes;
      if (!Array.isArray(nodes)) continue;

      for (const node of nodes) {
        if (budget <= 0) break;
        if (node.visualSnapshot) {
          continue;
        }

        const el = resolveTargetToElement(win, doc, node.target);
        if (!el) {
          node.visualSnapshot = { v: 1, err: 'unresolved' };
          budget -= 1;
          continue;
        }

        node.visualSnapshot = captureElementSubtreeSnapshot(win, el, {
          ...vsOpts.element,
          styleProps: vsOpts.styleProps,
        });
        budget -= 1;
      }
    }
  }
}

/**
 * @param {Window} win
 * @param {Document} doc
 * @param {object} store-like { initial }
 * @param {ReturnType<typeof normalizeVisualSnapshotOptions>} vsOpts
 */
export function captureInitialPageVisualForStore(win, doc, store, vsOpts) {
  if (!vsOpts.enabled || !vsOpts.pageOverview?.enabled) {
    store.initialPageVisual = null;
    return;
  }

  try {
    store.initialPageVisual = capturePageOverview(win, doc, {
      ...vsOpts.pageOverview,
      styleProps: vsOpts.styleProps,
    });
  } catch {
    store.initialPageVisual = { v: 1, kind: 'page', err: 'capture-failed' };
  }
}
